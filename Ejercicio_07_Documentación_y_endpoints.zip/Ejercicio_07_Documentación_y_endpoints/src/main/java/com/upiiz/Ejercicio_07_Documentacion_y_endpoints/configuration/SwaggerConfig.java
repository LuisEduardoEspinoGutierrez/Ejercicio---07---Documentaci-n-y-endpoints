package com.upiiz.Ejercicio_07_Documentacion_y_endpoints.configuration;


import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.*;
import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.context.annotation.Configuration;


@Configuration
@OpenAPIDefinition(
        info = @Info(
                title = "API de Empleados",
                version = "1.0",
                description = "Documentación de la API REST para la gestión de empleados. \\nRepositorio: https://github.com/LuisEduardoEspinoGutierrez",
                termsOfService = "https://www.zacatecas.ipn.mx",
                contact = @Contact(name = "Soporte API", email = "espinogutierrezluiseduardo@gmail.com", url = "https://mail.google.com"),
                license = @License(name = "Licencia MIT", url = "https://opensource.org/licenses/MIT")
        ),
        servers = {
                @Server(url = "http://localhost:8080", description = "Servidor local de desarrollo")
        }
)
public class SwaggerConfig
{

}
