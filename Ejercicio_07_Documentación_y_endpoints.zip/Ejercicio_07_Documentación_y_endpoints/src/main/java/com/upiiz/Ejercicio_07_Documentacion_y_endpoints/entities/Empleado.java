package com.upiiz.Ejercicio_07_Documentacion_y_endpoints.entities;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

@Entity
@Table(name="empleados")
@Schema(description = "Entidad que representa a un empleado de la empresa")
public class Empleado
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(accessMode = Schema.AccessMode.READ_ONLY, description = "Identificador único del empleado")

    private Long id;

    @NotBlank
    @Size(max = 100)  //tamaño maximo  varchar100
    @Schema(description = "Nombre del empleado", example = "Luis Eduardo")
    private String nombre;

    @NotBlank
    @Size(max = 100)
    @Schema(description = "Apellido del empleado", example = "Espino Gtz")
    private String apellido;

    @NotBlank
    @Size(max = 80)
    @Schema(description = "Puesto o cargo del empleado", example = "Desarrollador Backend")
    private String puesto;

    @NotNull
    @DecimalMin(value = "0.0", inclusive = false)
    @Schema(description = "Sueldo mensual del empleado", example = "15000.00")
    private Double salario;

    @NotNull
    @Schema(description = "Fecha de contratación", example = "2024-01-15")
    private LocalDate fechaContratacion;

    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getApellido() { return apellido; }
    public void setApellido(String apellido) { this.apellido = apellido; }

    public String getPuesto() { return puesto; }
    public void setPuesto(String puesto) { this.puesto = puesto; }

    public Double getSalario() { return salario; }
    public void setSalario(Double salario) { this.salario = salario; }

    public LocalDate getFechaContratacion() { return fechaContratacion; }
    public void setFechaContratacion(LocalDate fechaContratacion) { this.fechaContratacion = fechaContratacion; }

}
