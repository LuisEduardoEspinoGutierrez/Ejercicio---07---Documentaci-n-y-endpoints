package com.upiiz.Ejercicio_07_Documentacion_y_endpoints.services;

import com.upiiz.Ejercicio_07_Documentacion_y_endpoints.entities.Empleado;
import com.upiiz.Ejercicio_07_Documentacion_y_endpoints.repositories.EmpleadoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmpleadoService
{
    private final EmpleadoRepository repository;

    public EmpleadoService(EmpleadoRepository repository) {
        this.repository = repository;
    }

    public List<Empleado> findAll() {
        return repository.findAll();
    }

    public Optional<Empleado> findById(Long id) {
        return repository.findById(id);
    }

    public Empleado save(Empleado empleado) {
        return repository.save(empleado);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }

}
