package com.upiiz.Ejercicio_07_Documentacion_y_endpoints;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio07DocumentacionYEndpointsApplication
{

	public static void main(String[] args)
	{
		SpringApplication.run(Ejercicio07DocumentacionYEndpointsApplication.class, args);
	}

}

