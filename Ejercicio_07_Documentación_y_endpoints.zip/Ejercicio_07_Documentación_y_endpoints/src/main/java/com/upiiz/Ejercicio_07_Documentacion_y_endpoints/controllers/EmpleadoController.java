package com.upiiz.Ejercicio_07_Documentacion_y_endpoints.controllers;


import com.upiiz.Ejercicio_07_Documentacion_y_endpoints.entities.Empleado;
import com.upiiz.Ejercicio_07_Documentacion_y_endpoints.services.EmpleadoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.*;
import io.swagger.v3.oas.annotations.responses.*;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@RequestMapping("api/empleados")
@Tag(name = "Empleados", description = "Endpoints para gestión de empleados")
public class EmpleadoController
{
    private final EmpleadoService service;

    public EmpleadoController(EmpleadoService service) {
        this.service = service;
    }

    @Operation(summary = "Listar todos los empleados")
    @ApiResponse(responseCode = "200", description = "Lista obtenida correctamente")
    @GetMapping
    public List<Empleado> listar() {
        return service.findAll();
    }

    @Operation(summary = "Obtener un empleado por ID")
    @ApiResponse(responseCode = "200", description = "Empleado encontrado")
    @ApiResponse(responseCode = "404", description = "Empleado no encontrado")
    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerPorId(@PathVariable Long id) {
        return service.findById(id)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(Map.of("estado", 404, "mensaje", "Empleado no encontrado")));
    }

    @Operation(summary = "Registrar un nuevo empleado")
    @ApiResponse(responseCode = "201", description = "Empleado creado correctamente")
    @ApiResponse(responseCode = "400", description = "Datos inválidos")
    @PostMapping
    public ResponseEntity<?> crear(@Valid @RequestBody Empleado empleado) {
        Empleado nuevo = service.save(empleado);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(Map.of("estado", 201, "mensaje", "Empleado creado correctamente", "empleado", nuevo));
    }

    @Operation(summary = "Actualizar un empleado existente")
    @ApiResponse(responseCode = "200", description = "Empleado actualizado")
    @ApiResponse(responseCode = "404", description = "Empleado no encontrado")
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(@PathVariable Long id, @Valid @RequestBody Empleado datos) {
        return service.findById(id).map(emp -> {
            emp.setNombre(datos.getNombre());
            emp.setApellido(datos.getApellido());
            emp.setPuesto(datos.getPuesto());
            emp.setSalario(datos.getSalario());
            emp.setFechaContratacion(datos.getFechaContratacion());
            service.save(emp);
            return ResponseEntity.ok(Map.of("estado", 200, "mensaje", "Empleado actualizado correctamente"));
        }).orElse(ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(Map.of("estado", 404, "mensaje", "Empleado no encontrado")));
    }

    @Operation(summary = "Eliminar un empleado")
    @ApiResponse(responseCode = "204", description = "Empleado eliminado correctamente")
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        if (service.findById(id).isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("estado", 404, "mensaje", "Empleado no encontrado"));
        }
        service.delete(id);
        return ResponseEntity.status(HttpStatus.NO_CONTENT)
                .body(Map.of("estado", 204, "mensaje", "Empleado eliminado correctamente"));

    }
}
