package com.upiiz.Ejercicio_07_Documentacion_y_endpoints.repositories;

import com.upiiz.Ejercicio_07_Documentacion_y_endpoints.entities.Empleado;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmpleadoRepository extends JpaRepository <Empleado, Long>
{

}
