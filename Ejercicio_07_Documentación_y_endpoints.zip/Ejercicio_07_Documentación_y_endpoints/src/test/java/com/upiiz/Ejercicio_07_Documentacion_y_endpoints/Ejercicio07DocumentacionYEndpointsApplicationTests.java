package com.upiiz.Ejercicio_07_Documentacion_y_endpoints;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio07DocumentacionYEndpointsApplicationTests {

	@Test
	void contextLoads() {
	}

}
